"""
Portfolio management API endpoints
"""
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from app.database import get_db
from app.models import Portfolio, Client
from app.schemas import PortfolioCreate, PortfolioResponse
from app.services.portfolio_service import PortfolioService
from typing import List

router = APIRouter(prefix="/api/portfolio", tags=["portfolio"])


@router.post("/generate", response_model=dict, status_code=201)
def generate_portfolio(portfolio: PortfolioCreate, db: Session = Depends(get_db)):
    """Generate personalized portfolio for client"""
    try:
        result = PortfolioService.generate_portfolio(
            client_id=portfolio.client_id,
            total_investment=float(portfolio.total_investment),
            db=db
        )
        return result
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error generating portfolio: {str(e)}")


@router.get("/{client_id}", response_model=dict)
def get_portfolio(client_id: int, db: Session = Depends(get_db)):
    """Get latest portfolio for client"""
    portfolio = db.query(Portfolio).filter(
        Portfolio.client_id == client_id
    ).order_by(Portfolio.created_at.desc()).first()
    
    if not portfolio:
        raise HTTPException(status_code=404, detail="Portfolio not found")
    
    # Get holdings
    holdings = []
    for holding in portfolio.holdings:
        holdings.append({
            'ticker': holding.stock_ticker,
            'company_name': holding.company_name,
            'sector': holding.sector,
            'allocation_percent': float(holding.allocation_percent),
            'investment_amount': float(holding.investment_amount),
            'predicted_return_7d': float(holding.predicted_return_7d),
            'predicted_return_30d': float(holding.predicted_return_30d),
            'current_price': float(holding.current_price) if holding.current_price else 0,
            'risk_classification': holding.risk_classification
        })
    
    return {
        'portfolio_id': portfolio.id,
        'client_id': portfolio.client_id,
        'total_investment': float(portfolio.total_investment),
        'risk_profile': portfolio.risk_profile,
        'created_at': portfolio.created_at,
        'holdings': holdings
    }

