"""
Service for portfolio construction and management
"""
import numpy as np
from sqlalchemy.orm import Session
from app.models import Portfolio, PortfolioHolding, Client, RiskAssessment
from app.services.yfinance_service import YFinanceService
from app.ml_models.stock_predictor import StockPredictor
from typing import List, Dict

class PortfolioService:
    """Service for portfolio operations"""
    
    @staticmethod
    def generate_portfolio(
        client_id: int,
        total_investment: float,
        db: Session,
        risk_profile: str = None
    ) -> Dict:
        """
        Generate personalized portfolio for client
        
        Returns:
            dict with portfolio details and holdings
        """
        # Get client
        client = db.query(Client).filter(Client.id == client_id).first()
        if not client:
            raise ValueError(f"Client {client_id} not found")
        
        # Get risk profile if not provided
        if not risk_profile:
            risk_assessment = db.query(RiskAssessment).filter(
                RiskAssessment.client_id == client_id
            ).order_by(RiskAssessment.assessment_date.desc()).first()
            
            if risk_assessment:
                risk_profile = risk_assessment.risk_profile
            else:
                risk_profile = 'Balanced'
        
        # Get available stocks
        stocks_data = YFinanceService.get_nifty50_stocks_with_data(db)
        
        if not stocks_data:
            raise ValueError("No stock data available")
        
        # Filter stocks based on risk profile
        filtered_stocks = PortfolioService._filter_stocks_by_risk(stocks_data, risk_profile)
        
        if len(filtered_stocks) < 3:
            # If not enough stocks, use all available
            filtered_stocks = stocks_data[:8]
        
        # Select top stocks (5-8)
        selected_stocks = filtered_stocks[:min(8, len(filtered_stocks))]
        
        # Get LSTM predictions
        predictor = StockPredictor()
        predictions = {}
        failed_tickers = []
        
        for stock in selected_stocks:
            ticker = stock['ticker']
            try:
                pred = predictor.predict(ticker, days=30)
                predictions[ticker] = pred
                
                # Calculate predicted returns
                current_price = pred.get('current_price', stock['current_price'])
                pred_7d = pred.get('predicted_price_7d', current_price)
                pred_30d = pred.get('predicted_price_30d', current_price)
                
                stock['predicted_return_7d'] = ((pred_7d - current_price) / current_price) * 100
                stock['predicted_return_30d'] = ((pred_30d - current_price) / current_price) * 100
                stock['current_price'] = current_price
                
            except Exception as e:
                failed_tickers.append(ticker)
                raise ValueError(f"Cannot generate predictions for {ticker}. Model training required. Error: {str(e)}")
        
        if failed_tickers:
            raise ValueError(f"Failed to predict for stocks: {', '.join(failed_tickers)}. Please ensure models are trained.")
        
        # Calculate allocations
        allocations = PortfolioService._calculate_allocations(
            selected_stocks,
            risk_profile,
            total_investment
        )
        
        # Create portfolio
        portfolio = Portfolio(
            client_id=client_id,
            total_investment=total_investment,
            risk_profile=risk_profile
        )
        db.add(portfolio)
        db.flush()
        
        # Create holdings
        holdings = []
        for stock, allocation in zip(selected_stocks, allocations):
            holding = PortfolioHolding(
                portfolio_id=portfolio.id,
                stock_ticker=stock['ticker'],
                company_name=stock['company_name'],
                sector=stock.get('sector', 'Unknown'),
                allocation_percent=allocation['percent'],
                investment_amount=allocation['amount'],
                predicted_return_7d=stock.get('predicted_return_7d', 0),
                predicted_return_30d=stock.get('predicted_return_30d', 0),
                current_price=stock.get('current_price', 0),
                risk_classification=stock.get('risk_classification', 'Medium Risk')
            )
            db.add(holding)
            holdings.append(holding)
        
        db.commit()
        db.refresh(portfolio)
        
        return {
            'portfolio_id': portfolio.id,
            'client_id': client_id,
            'total_investment': float(total_investment),
            'risk_profile': risk_profile,
            'holdings': [
                {
                    'ticker': h.stock_ticker,
                    'company_name': h.company_name,
                    'sector': h.sector,
                    'allocation_percent': float(h.allocation_percent),
                    'investment_amount': float(h.investment_amount),
                    'predicted_return_7d': float(h.predicted_return_7d),
                    'predicted_return_30d': float(h.predicted_return_30d),
                    'current_price': float(h.current_price) if h.current_price else 0,
                    'risk_classification': h.risk_classification
                }
                for h in holdings
            ]
        }
    
    @staticmethod
    def _filter_stocks_by_risk(stocks_data: List[Dict], risk_profile: str) -> List[Dict]:
        """Filter stocks based on risk profile"""
        if risk_profile in ['Conservative', 'Moderate Conservative']:
            return [s for s in stocks_data if s.get('risk_classification') == 'Low Risk']
        elif risk_profile == 'Balanced':
            return [s for s in stocks_data if s.get('risk_classification') in ['Low Risk', 'Medium Risk']]
        else:  # Growth Oriented, Aggressive Growth
            return [s for s in stocks_data if s.get('risk_classification') in ['Medium Risk', 'High Risk']]
    
    @staticmethod
    def _calculate_allocations(stocks: List[Dict], risk_profile: str, total_investment: float) -> List[Dict]:
        """Calculate portfolio allocations"""
        num_stocks = len(stocks)
        
        if risk_profile in ['Conservative', 'Moderate Conservative']:
            # Equal allocation
            percent_per_stock = 100 / num_stocks
            allocations = [
                {'percent': percent_per_stock, 'amount': (total_investment * percent_per_stock) / 100}
                for _ in stocks
            ]
        elif risk_profile == 'Balanced':
            # Weighted allocation (higher for first stocks)
            weights = np.linspace(20, 8, num_stocks)
            weights = weights / weights.sum() * 100
            allocations = [
                {'percent': float(w), 'amount': (total_investment * w) / 100}
                for w in weights
            ]
        else:  # Growth Oriented, Aggressive Growth
            # Concentrated allocation
            weights = np.linspace(25, 5, num_stocks)
            weights = weights / weights.sum() * 100
            allocations = [
                {'percent': float(w), 'amount': (total_investment * w) / 100}
                for w in weights
            ]
        
        return allocations

