"""
Stock prediction API endpoints
"""
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from app.database import get_db
from app.ml_models.stock_predictor import StockPredictor
from app.schemas import StockPredictionResponse
from typing import List

router = APIRouter(prefix="/api/predictions", tags=["predictions"])


@router.get("/{ticker}", response_model=dict)
def get_stock_prediction(ticker: str, days: int = 30, db: Session = Depends(get_db)):
    """Get LSTM predictions for a stock"""
    try:
        predictor = StockPredictor()
        predictions = predictor.predict(ticker, days=days)
        return predictions
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error predicting for {ticker}: {str(e)}")


@router.post("/batch", response_model=dict)
def batch_predict(tickers: List[str], days: int = 30, db: Session = Depends(get_db)):
    """Get predictions for multiple stocks"""
    try:
        predictor = StockPredictor()
        results = predictor.batch_predict(tickers, days=days)
        return {"predictions": results}
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error in batch prediction: {str(e)}")

