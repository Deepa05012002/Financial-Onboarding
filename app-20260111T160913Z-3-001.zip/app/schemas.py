"""
Pydantic schemas for request/response validation
"""
from pydantic import BaseModel, Field
from typing import List, Optional
from datetime import datetime, date
from decimal import Decimal


# Client Schemas
class ClientBase(BaseModel):
    client_name: str = Field(..., min_length=1, max_length=255)
    age: int = Field(..., ge=18, le=100)
    monthly_income: Decimal = Field(..., gt=0)
    monthly_expenses: Decimal = Field(..., ge=0)
    dependents: int = Field(default=0, ge=0)
    employment_status: str = Field(default="Employed")
    emergency_fund: Decimal = Field(default=0, ge=0)


class ClientCreate(ClientBase):
    pass


class ClientResponse(ClientBase):
    id: int
    created_at: datetime
    updated_at: Optional[datetime]
    
    class Config:
        from_attributes = True


# Risk Assessment Schemas
class RiskAssessmentBase(BaseModel):
    risk_profile: str
    risk_score: Decimal
    confidence_score: Decimal = Field(default=0, ge=0, le=100)


class RiskAssessmentCreate(BaseModel):
    client_id: int
    investment_horizon: int = Field(..., ge=1, le=30)  # years
    volatility_tolerance: int = Field(..., ge=1, le=4)  # 1-4 scale
    financial_knowledge: int = Field(..., ge=1, le=4)  # 1-4 scale
    income_stability: int = Field(..., ge=1, le=4)  # 1-4 scale
    risk_capacity: int = Field(..., ge=1, le=4)  # 1-4 scale


class RiskAssessmentResponse(RiskAssessmentBase):
    id: int
    client_id: int
    ml_model_version: str
    assessment_date: datetime
    
    class Config:
        from_attributes = True


# Portfolio Schemas
class PortfolioHoldingBase(BaseModel):
    stock_ticker: str
    company_name: str
    sector: Optional[str] = None
    allocation_percent: Decimal
    investment_amount: Decimal
    predicted_return_7d: Optional[Decimal] = None
    predicted_return_30d: Optional[Decimal] = None
    current_price: Optional[Decimal] = None
    risk_classification: Optional[str] = None


class PortfolioCreate(BaseModel):
    client_id: int
    total_investment: Decimal = Field(..., gt=0)


class PortfolioResponse(BaseModel):
    id: int
    client_id: int
    total_investment: Decimal
    risk_profile: str
    created_at: datetime
    holdings: List[PortfolioHoldingBase]
    
    class Config:
        from_attributes = True


# Stock Prediction Schemas
class StockPredictionResponse(BaseModel):
    stock_ticker: str
    prediction_date: date
    predicted_price_1d: Optional[Decimal]
    predicted_price_7d: Optional[Decimal]
    predicted_price_30d: Optional[Decimal]
    confidence_1d: Optional[Decimal]
    confidence_7d: Optional[Decimal]
    confidence_30d: Optional[Decimal]
    
    class Config:
        from_attributes = True


# Market Data Schemas
class MarketDataResponse(BaseModel):
    stock_ticker: str
    date: date
    close_price: Decimal
    volatility: Optional[Decimal]
    
    class Config:
        from_attributes = True

