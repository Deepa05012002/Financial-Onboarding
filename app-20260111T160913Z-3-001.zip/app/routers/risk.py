"""
Risk assessment API endpoints
"""
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from app.database import get_db
from app.models import Client, RiskAssessment
from app.schemas import RiskAssessmentCreate, RiskAssessmentResponse
from app.ml_models.risk_classifier import RiskClassifier
from typing import List

router = APIRouter(prefix="/api/risk", tags=["risk"])


@router.post("/assess", response_model=RiskAssessmentResponse, status_code=201)
def assess_risk(assessment: RiskAssessmentCreate, db: Session = Depends(get_db)):
    """Assess client risk profile using ML model"""
    # Verify client exists
    client = db.query(Client).filter(Client.id == assessment.client_id).first()
    if not client:
        raise HTTPException(status_code=404, detail="Client not found")
    
    # Get client data
    client_data = {
        'age': client.age,
        'monthly_income': float(client.monthly_income),
        'monthly_expenses': float(client.monthly_expenses),
        'dependents': client.dependents,
        'emergency_fund': float(client.emergency_fund) if client.emergency_fund else 0
    }
    
    # Questionnaire responses
    questionnaire = {
        'investment_horizon': assessment.investment_horizon,
        'volatility_tolerance': assessment.volatility_tolerance,
        'financial_knowledge': assessment.financial_knowledge,
        'income_stability': assessment.income_stability,
        'risk_capacity': assessment.risk_capacity
    }
    
    # Predict using ML model
    classifier = RiskClassifier()
    prediction = classifier.predict(client_data, questionnaire)
    
    # Create risk assessment record
    risk_assessment = RiskAssessment(
        client_id=assessment.client_id,
        risk_profile=prediction['risk_profile'],
        risk_score=prediction['risk_score'],
        confidence_score=prediction['confidence_score'],
        ml_model_version=classifier.model_version
    )
    
    db.add(risk_assessment)
    db.commit()
    db.refresh(risk_assessment)
    
    return risk_assessment


@router.get("/{client_id}", response_model=RiskAssessmentResponse)
def get_risk_assessment(client_id: int, db: Session = Depends(get_db)):
    """Get latest risk assessment for client"""
    assessment = db.query(RiskAssessment).filter(
        RiskAssessment.client_id == client_id
    ).order_by(RiskAssessment.assessment_date.desc()).first()
    
    if not assessment:
        raise HTTPException(status_code=404, detail="Risk assessment not found")
    
    return assessment

