"""
Random Forest Model for Risk Classification
World-class implementation with proper training
"""
import numpy as np
import pandas as pd
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import train_test_split, cross_val_score
from sklearn.preprocessing import LabelEncoder
import joblib
import os
from datetime import datetime

class RiskClassifier:
    """Random Forest-based risk profile classifier"""
    
    def __init__(self, model_dir="models"):
        self.model_dir = model_dir
        self.model = None
        self.label_encoder = LabelEncoder()
        self.model_version = "v1.0"
        self.feature_names = [
            'age', 'monthly_income', 'monthly_expenses', 'dependents',
            'emergency_fund', 'investment_horizon', 'volatility_tolerance',
            'financial_knowledge', 'income_stability', 'risk_capacity'
        ]
        
        # Create models directory if it doesn't exist
        os.makedirs(model_dir, exist_ok=True)
    
    def generate_training_data(self, n_samples: int = 2000):
        """
        Generate synthetic training data based on financial advisory rules
        This creates realistic training data for the model
        """
        np.random.seed(42)
        
        data = []
        labels = []
        
        risk_profiles = ['Conservative', 'Moderate Conservative', 'Balanced', 'Growth Oriented', 'Aggressive Growth']
        
        for _ in range(n_samples):
            age = np.random.randint(25, 65)
            monthly_income = np.random.uniform(30000, 500000)
            monthly_expenses = monthly_income * np.random.uniform(0.4, 0.8)
            dependents = np.random.randint(0, 4)
            emergency_fund = np.random.uniform(50000, 1000000)
            
            # Investment horizon (years)
            investment_horizon = np.random.randint(1, 30)
            
            # Questionnaire responses (1-4 scale)
            volatility_tolerance = np.random.randint(1, 5)
            financial_knowledge = np.random.randint(1, 5)
            income_stability = np.random.randint(1, 5)
            risk_capacity = np.random.randint(1, 5)
            
            # Calculate risk score (similar to original logic)
            score = (
                min(investment_horizon, 15) * 1.0 +
                volatility_tolerance * 3.75 +
                financial_knowledge * 3.75 +
                income_stability * 3.75 +
                risk_capacity * 3.75
            )
            
            # Determine risk profile based on score
            percentage = (score / 75) * 100
            if percentage <= 30:
                risk_profile = 'Conservative'
            elif percentage <= 50:
                risk_profile = 'Moderate Conservative'
            elif percentage <= 70:
                risk_profile = 'Balanced'
            elif percentage <= 85:
                risk_profile = 'Growth Oriented'
            else:
                risk_profile = 'Aggressive Growth'
            
            features = [
                age, monthly_income, monthly_expenses, dependents,
                emergency_fund, investment_horizon, volatility_tolerance,
                financial_knowledge, income_stability, risk_capacity
            ]
            
            data.append(features)
            labels.append(risk_profile)
        
        return np.array(data), np.array(labels)
    
    def train(self, n_samples: int = 2000, n_estimators: int = 100):
        """
        Train Random Forest classifier
        """
        print("Training Risk Classifier...")
        
        # Generate training data
        X, y = self.generate_training_data(n_samples)
        
        # Encode labels
        y_encoded = self.label_encoder.fit_transform(y)
        
        # Split data
        X_train, X_test, y_train, y_test = train_test_split(
            X, y_encoded, test_size=0.2, random_state=42, stratify=y_encoded
        )
        
        # Build model
        self.model = RandomForestClassifier(
            n_estimators=n_estimators,
            max_depth=10,
            min_samples_split=5,
            min_samples_leaf=2,
            random_state=42,
            n_jobs=-1
        )
        
        # Train
        self.model.fit(X_train, y_train)
        
        # Evaluate
        train_score = self.model.score(X_train, y_train)
        test_score = self.model.score(X_test, y_test)
        cv_scores = cross_val_score(self.model, X_train, y_train, cv=5)
        
        print(f"Training Accuracy: {train_score:.4f}")
        print(f"Test Accuracy: {test_score:.4f}")
        print(f"Cross-Validation Score: {cv_scores.mean():.4f} (+/- {cv_scores.std() * 2:.4f})")
        
        # Save model
        model_path = f"{self.model_dir}/risk_classifier.pkl"
        encoder_path = f"{self.model_dir}/risk_label_encoder.pkl"
        
        joblib.dump(self.model, model_path)
        joblib.dump(self.label_encoder, encoder_path)
        
        print(f"Model saved to {model_path}")
        return self.model
    
    def load_model(self):
        """Load trained model"""
        model_path = f"{self.model_dir}/risk_classifier.pkl"
        encoder_path = f"{self.model_dir}/risk_label_encoder.pkl"
        
        if os.path.exists(model_path) and os.path.exists(encoder_path):
            self.model = joblib.load(model_path)
            self.label_encoder = joblib.load(encoder_path)
            return True
        return False
    
    def predict(self, client_data: dict, questionnaire_responses: dict):
        """
        Predict risk profile for a client
        
        Args:
            client_data: dict with age, monthly_income, monthly_expenses, dependents, emergency_fund
            questionnaire_responses: dict with investment_horizon, volatility_tolerance, 
                                   financial_knowledge, income_stability, risk_capacity
        
        Returns:
            dict with risk_profile, risk_score, confidence_score, probabilities
        """
        # Load model if not loaded
        if self.model is None:
            if not self.load_model():
                # Train if model doesn't exist
                self.train()
        
        # Prepare features
        features = np.array([[
            client_data.get('age', 30),
            client_data.get('monthly_income', 50000),
            client_data.get('monthly_expenses', 30000),
            client_data.get('dependents', 0),
            client_data.get('emergency_fund', 0),
            questionnaire_responses.get('investment_horizon', 5),
            questionnaire_responses.get('volatility_tolerance', 2),
            questionnaire_responses.get('financial_knowledge', 2),
            questionnaire_responses.get('income_stability', 3),
            questionnaire_responses.get('risk_capacity', 2)
        ]])
        
        # Predict
        prediction = self.model.predict(features)[0]
        probabilities = self.model.predict_proba(features)[0]
        
        # Get risk profile
        risk_profile = self.label_encoder.inverse_transform([prediction])[0]
        
        # Calculate confidence (max probability)
        confidence_score = max(probabilities) * 100
        
        # Calculate risk score (0-75 scale, similar to original)
        risk_score = (
            min(questionnaire_responses.get('investment_horizon', 5), 15) * 1.0 +
            questionnaire_responses.get('volatility_tolerance', 2) * 3.75 +
            questionnaire_responses.get('financial_knowledge', 2) * 3.75 +
            questionnaire_responses.get('income_stability', 3) * 3.75 +
            questionnaire_responses.get('risk_capacity', 2) * 3.75
        )
        
        # Get probabilities for all classes
        all_profiles = self.label_encoder.classes_
        profile_probabilities = {
            profile: float(prob) * 100 
            for profile, prob in zip(all_profiles, probabilities)
        }
        
        return {
            'risk_profile': risk_profile,
            'risk_score': float(risk_score),
            'confidence_score': float(confidence_score),
            'probabilities': profile_probabilities
        }
    
    def get_feature_importance(self):
        """Get feature importance from the model"""
        if self.model is None:
            if not self.load_model():
                return None
        
        importance = self.model.feature_importances_
        feature_importance = dict(zip(self.feature_names, importance))
        return sorted(feature_importance.items(), key=lambda x: x[1], reverse=True)

