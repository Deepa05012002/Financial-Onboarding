"""
FastAPI Main Application
"""
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from app.routers import clients, risk, portfolio, predictions
import os

app = FastAPI(
    title="Financial Onboarding API",
    description="Advanced Financial Onboarding System with ML Models",
    version="2.0.0"
)

# CORS middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # In production, specify actual origins
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Include routers
app.include_router(clients.router)
app.include_router(risk.router)
app.include_router(portfolio.router)
app.include_router(predictions.router)


@app.get("/")
def root():
    """Root endpoint"""
    return {
        "message": "Financial Onboarding API",
        "version": "2.0.0",
        "endpoints": {
            "clients": "/api/clients",
            "risk": "/api/risk",
            "portfolio": "/api/portfolio",
            "predictions": "/api/predictions"
        },
        "docs": "/docs"
    }


@app.get("/health")
def health_check():
    """Health check endpoint"""
    return {"status": "healthy"}


if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)

