"""
SQLAlchemy database models
"""
from sqlalchemy import Column, Integer, String, Numeric, ForeignKey, Date, DateTime, Text
from sqlalchemy.orm import relationship
from sqlalchemy.sql import func
from app.database import Base


class Client(Base):
    """Client profile model"""
    __tablename__ = "clients"
    
    id = Column(Integer, primary_key=True, index=True)
    client_name = Column(String(255), nullable=False)
    age = Column(Integer, nullable=False)
    monthly_income = Column(Numeric(12, 2), nullable=False)
    monthly_expenses = Column(Numeric(12, 2), nullable=False)
    dependents = Column(Integer, default=0)
    employment_status = Column(String(50), default="Employed")
    emergency_fund = Column(Numeric(12, 2), default=0)
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(DateTime(timezone=True), onupdate=func.now())
    
    # Relationships
    risk_assessments = relationship("RiskAssessment", back_populates="client")
    portfolios = relationship("Portfolio", back_populates="client")


class RiskAssessment(Base):
    """Risk assessment model"""
    __tablename__ = "risk_assessments"
    
    id = Column(Integer, primary_key=True, index=True)
    client_id = Column(Integer, ForeignKey("clients.id"), nullable=False)
    risk_profile = Column(String(50), nullable=False)  # ML predicted
    risk_score = Column(Numeric(5, 2), nullable=False)
    confidence_score = Column(Numeric(5, 2), default=0)  # ML confidence
    ml_model_version = Column(String(20), default="v1.0")
    assessment_date = Column(DateTime(timezone=True), server_default=func.now())
    
    # Relationships
    client = relationship("Client", back_populates="risk_assessments")


class Portfolio(Base):
    """Portfolio model"""
    __tablename__ = "portfolios"
    
    id = Column(Integer, primary_key=True, index=True)
    client_id = Column(Integer, ForeignKey("clients.id"), nullable=False)
    total_investment = Column(Numeric(12, 2), nullable=False)
    risk_profile = Column(String(50), nullable=False)
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    
    # Relationships
    client = relationship("Client", back_populates="portfolios")
    holdings = relationship("PortfolioHolding", back_populates="portfolio")


class PortfolioHolding(Base):
    """Portfolio holdings model"""
    __tablename__ = "portfolio_holdings"
    
    id = Column(Integer, primary_key=True, index=True)
    portfolio_id = Column(Integer, ForeignKey("portfolios.id"), nullable=False)
    stock_ticker = Column(String(20), nullable=False)
    company_name = Column(String(255), nullable=False)
    sector = Column(String(100))
    allocation_percent = Column(Numeric(5, 2), nullable=False)
    investment_amount = Column(Numeric(12, 2), nullable=False)
    predicted_return_7d = Column(Numeric(5, 2), default=0)  # LSTM prediction
    predicted_return_30d = Column(Numeric(5, 2), default=0)
    current_price = Column(Numeric(10, 2))
    risk_classification = Column(String(50))
    
    # Relationships
    portfolio = relationship("Portfolio", back_populates="holdings")


class StockPrediction(Base):
    """Stock predictions cache model"""
    __tablename__ = "stock_predictions"
    
    id = Column(Integer, primary_key=True, index=True)
    stock_ticker = Column(String(20), nullable=False, index=True)
    prediction_date = Column(Date, nullable=False)
    predicted_price_1d = Column(Numeric(10, 2))
    predicted_price_7d = Column(Numeric(10, 2))
    predicted_price_30d = Column(Numeric(10, 2))
    confidence_1d = Column(Numeric(5, 2), default=0)
    confidence_7d = Column(Numeric(5, 2), default=0)
    confidence_30d = Column(Numeric(5, 2), default=0)
    model_version = Column(String(20), default="v1.0")
    created_at = Column(DateTime(timezone=True), server_default=func.now())


class MarketData(Base):
    """Market data cache model"""
    __tablename__ = "market_data"
    
    id = Column(Integer, primary_key=True, index=True)
    stock_ticker = Column(String(20), nullable=False, index=True)
    date = Column(Date, nullable=False, index=True)
    open_price = Column(Numeric(10, 2))
    high_price = Column(Numeric(10, 2))
    low_price = Column(Numeric(10, 2))
    close_price = Column(Numeric(10, 2), nullable=False)
    volume = Column(Integer)
    volatility = Column(Numeric(8, 4))
    updated_at = Column(DateTime(timezone=True), server_default=func.now(), onupdate=func.now())

