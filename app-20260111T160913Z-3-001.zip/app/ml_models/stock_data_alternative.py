"""
Alternative data source for Indian stocks when yfinance fails
Uses realistic synthetic data based on actual stock patterns
"""
import pandas as pd
import numpy as np
from datetime import datetime, timedelta
import yfinance as yf
import time

class StockDataFetcher:
    """Robust stock data fetcher with fallback to realistic synthetic data"""
    
    # Realistic price ranges for Indian stocks (in INR)
    STOCK_BASE_PRICES = {
        'RELIANCE.NS': 2500,
        'TCS.NS': 3500,
        'HDFCBANK.NS': 1600,
        'INFY.NS': 1400,
        'ICICIBANK.NS': 900,
        'HINDUNILVR.NS': 2400,
        'ITC.NS': 450,
        'BHARTIARTL.NS': 1100,
        'MARUTI.NS': 9500,
        'ASIANPAINT.NS': 2800,
    }
    
    @staticmethod
    def generate_realistic_stock_data(ticker: str, days: int = 365*2):
        """
        Generate realistic synthetic stock data based on actual patterns
        Uses random walk with drift and volatility matching real stocks
        """
        base_price = StockDataFetcher.STOCK_BASE_PRICES.get(ticker, 1000)
        
        # Generate dates
        end_date = datetime.now()
        start_date = end_date - timedelta(days=days)
        dates = pd.date_range(start=start_date, end=end_date, freq='D')
        dates = [d for d in dates if d.weekday() < 5]  # Only weekdays
        
        # Stock parameters (realistic for Indian market)
        daily_return = 0.0005  # ~0.05% daily return (12% annual)
        daily_volatility = 0.015  # ~1.5% daily volatility
        
        # Generate price series using geometric Brownian motion
        returns = np.random.normal(daily_return, daily_volatility, len(dates))
        prices = [base_price]
        
        for ret in returns[1:]:
            new_price = prices[-1] * (1 + ret)
            prices.append(max(new_price, base_price * 0.3))  # Prevent unrealistic drops
        
        # Create DataFrame
        df = pd.DataFrame({
            'Open': prices,
            'High': [p * (1 + abs(np.random.normal(0, 0.01))) for p in prices],
            'Low': [p * (1 - abs(np.random.normal(0, 0.01))) for p in prices],
            'Close': prices,
            'Volume': np.random.randint(1000000, 10000000, len(dates))
        }, index=dates)
        
        # Ensure High >= Close >= Low
        df['High'] = df[['High', 'Close']].max(axis=1)
        df['Low'] = df[['Low', 'Close']].min(axis=1)
        
        return df
    
    @staticmethod
    def fetch_with_fallback(ticker: str, period: str = "2y"):
        """
        Try to fetch real data, fallback to realistic synthetic data
        """
        # Try real data first with multiple attempts
        for attempt in range(3):
            try:
                stock = yf.Ticker(ticker)
                df = stock.history(period=period, timeout=15)
                if not df.empty and len(df) > 60:
                    print(f"  ✓ Fetched real data for {ticker}: {len(df)} rows")
                    return df
            except:
                if attempt < 2:
                    time.sleep(2 ** attempt)  # Exponential backoff
                continue
        
        # Fallback to synthetic data
        print(f"  ⚠️ Using realistic synthetic data for {ticker} (yfinance unavailable)")
        
        # Convert period to days
        period_days = {
            '5y': 365 * 5,
            '2y': 365 * 2,
            '1y': 365,
            '6mo': 180,
            '3mo': 90,
            '1mo': 30
        }.get(period, 365 * 2)
        
        return StockDataFetcher.generate_realistic_stock_data(ticker, period_days)

