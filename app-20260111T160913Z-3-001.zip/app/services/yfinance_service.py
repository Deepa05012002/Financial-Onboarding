"""
Service for fetching and caching stock market data using yfinance
"""
import yfinance as yf
import pandas as pd
from datetime import datetime, timedelta
from sqlalchemy.orm import Session
from app.models import MarketData, StockPrediction
from app.database import SessionLocal
import time

class YFinanceService:
    """Service for stock market data operations"""
    
    # NIFTY 50 tickers
    NIFTY_50_TICKERS = [
        'RELIANCE.NS', 'TCS.NS', 'HDFCBANK.NS', 'INFY.NS', 'ICICIBANK.NS',
        'HINDUNILVR.NS', 'ITC.NS', 'BHARTIARTL.NS', 'MARUTI.NS', 'ASIANPAINT.NS',
        'SUNPHARMA.NS', 'TITAN.NS', 'NESTLEIND.NS', 'BRITANNIA.NS', 'BAJFINANCE.NS',
        'KOTAKBANK.NS', 'NTPC.NS', 'COALINDIA.NS', 'ONGC.NS', 'POWERGRID.NS',
        'LT.NS', 'SBIN.NS', 'AXISBANK.NS', 'WIPRO.NS', 'ULTRACEMCO.NS',
        'TECHM.NS', 'HCLTECH.NS', 'TATAMOTORS.NS', 'JSWSTEEL.NS', 'TATASTEEL.NS',
        'ADANIENT.NS', 'ADANIPORTS.NS', 'APOLLOHOSP.NS', 'BAJAJFINSV.NS', 'BPCL.NS',
        'CIPLA.NS', 'DIVISLAB.NS', 'DRREDDY.NS', 'EICHERMOT.NS', 'GRASIM.NS',
        'HDFCLIFE.NS', 'HEROMOTOCO.NS', 'HINDALCO.NS', 'IOC.NS', 'INDUSINDBK.NS',
        'M&M.NS', 'SBILIFE.NS', 'SHREECEM.NS', 'TATACONSUM.NS', 'UPL.NS'
    ]
    
    @staticmethod
    def get_stock_info(ticker: str):
        """Get basic stock information"""
        try:
            stock = yf.Ticker(ticker)
            info = stock.info
            return {
                'ticker': ticker,
                'company_name': info.get('longName', ticker),
                'sector': info.get('sector', 'Unknown'),
                'market_cap': info.get('marketCap', 0),
                'current_price': info.get('currentPrice', 0)
            }
        except Exception as e:
            print(f"Error fetching info for {ticker}: {str(e)}")
            return None
    
    @staticmethod
    def fetch_and_cache_market_data(ticker: str, db: Session, days: int = 90):
        """
        Fetch stock data and cache in database
        Returns: DataFrame with market data
        """
        try:
            # Check if data exists in cache (last 7 days)
            cutoff_date = datetime.now().date() - timedelta(days=7)
            cached_data = db.query(MarketData).filter(
                MarketData.stock_ticker == ticker,
                MarketData.date >= cutoff_date
            ).order_by(MarketData.date.desc()).all()
            
            if len(cached_data) >= 5:  # If we have recent cached data
                # Convert to DataFrame
                data_dicts = [{
                    'Date': md.date,
                    'Close': float(md.close_price),
                    'Open': float(md.open_price) if md.open_price else float(md.close_price),
                    'High': float(md.high_price) if md.high_price else float(md.close_price),
                    'Low': float(md.low_price) if md.low_price else float(md.close_price),
                    'Volume': int(md.volume) if md.volume else 0
                } for md in cached_data]
                df = pd.DataFrame(data_dicts)
                df['Date'] = pd.to_datetime(df['Date'])
                df.set_index('Date', inplace=True)
                return df
            
            # Fetch fresh data
            stock = yf.Ticker(ticker)
            df = stock.history(period=f"{days}d")
            
            if df.empty:
                return None
            
            # Calculate volatility
            df['volatility'] = df['Close'].pct_change().rolling(window=20).std() * (252 ** 0.5) * 100
            
            # Cache in database
            for date, row in df.iterrows():
                existing = db.query(MarketData).filter(
                    MarketData.stock_ticker == ticker,
                    MarketData.date == date.date()
                ).first()
                
                if not existing:
                    market_data = MarketData(
                        stock_ticker=ticker,
                        date=date.date(),
                        open_price=float(row['Open']),
                        high_price=float(row['High']),
                        low_price=float(row['Low']),
                        close_price=float(row['Close']),
                        volume=int(row['Volume']) if 'Volume' in row else 0,
                        volatility=float(row['volatility']) if 'volatility' in row else None
                    )
                    db.add(market_data)
            
            db.commit()
            
            # Small delay to avoid rate limiting
            time.sleep(0.1)
            
            return df
        
        except Exception as e:
            print(f"Error fetching market data for {ticker}: {str(e)}")
            db.rollback()
            return None
    
    @staticmethod
    def classify_stock_risk(df: pd.DataFrame, de_ratio: float = None, revenue_growth: float = None):
        """
        Classify stock risk based on volatility and other factors
        Returns: 'Low Risk', 'Medium Risk', or 'High Risk'
        """
        if df is None or df.empty:
            return 'Medium Risk'
        
        # Calculate volatility
        volatility = df['Close'].pct_change().std() * (252 ** 0.5) * 100
        
        risk_score = 0
        
        # Volatility component (0-40 points)
        if volatility < 15:
            risk_score += 10
        elif volatility < 25:
            risk_score += 20
        elif volatility < 35:
            risk_score += 30
        else:
            risk_score += 40
        
        # Debt-to-equity component (0-30 points)
        if de_ratio is not None:
            if de_ratio < 0.5:
                risk_score += 5
            elif de_ratio < 1.0:
                risk_score += 15
            elif de_ratio < 2.0:
                risk_score += 25
            else:
                risk_score += 30
        
        # Revenue growth component (0-30 points)
        if revenue_growth is not None:
            if revenue_growth > 20:
                risk_score += 30
            elif revenue_growth > 10:
                risk_score += 20
            elif revenue_growth > 5:
                risk_score += 10
            else:
                risk_score += 5
        
        # Classify
        if risk_score < 30:
            return 'Low Risk'
        elif risk_score < 60:
            return 'Medium Risk'
        else:
            return 'High Risk'
    
    @staticmethod
    def get_nifty50_stocks_with_data(db: Session):
        """Get NIFTY 50 stocks with their data"""
        stocks_data = []
        
        for ticker in YFinanceService.NIFTY_50_TICKERS[:20]:  # Limit to 20 for faster processing
            try:
                # Fetch market data
                df = YFinanceService.fetch_and_cache_market_data(ticker, db)
                
                if df is None or df.empty:
                    continue
                
                # Get stock info
                info = YFinanceService.get_stock_info(ticker)
                
                if info is None:
                    continue
                
                # Classify risk
                risk_classification = YFinanceService.classify_stock_risk(df)
                
                # Get latest price
                current_price = float(df['Close'].iloc[-1])
                
                # Calculate market cap (simplified)
                market_cap = info.get('market_cap', 0) / 10000000  # Convert to crores
                
                stocks_data.append({
                    'ticker': ticker,
                    'company_name': info.get('company_name', ticker),
                    'sector': info.get('sector', 'Unknown'),
                    'current_price': current_price,
                    'market_cap_cr': market_cap,
                    'risk_classification': risk_classification,
                    'volatility': float(df['Close'].pct_change().std() * (252 ** 0.5) * 100) if len(df) > 1 else 0
                })
                
            except Exception as e:
                print(f"Error processing {ticker}: {str(e)}")
                continue
        
        return stocks_data

